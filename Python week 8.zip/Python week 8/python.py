
fruits = ["apple","banana","cherry"]

print(fruits[0])

fruits[1] = "blueberry"

print(fruits)